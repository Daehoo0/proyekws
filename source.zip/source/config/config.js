module.exports = {
    development: {
      username: "root",
      password: "",
      database: "db_travel2",
      host: "127.0.0.1",
      dialect: "mysql"
    },
    test: {
      username: "root",
      password: "",
      database: "db_travel2_test",
      host: "127.0.0.1",
      dialect: "mysql"
    },
    production: {
      username: "root",
      password: "",
      database: "db_travel2_prod",
      host: "127.0.0.1",
      dialect: "mysql"
    }
  };
  